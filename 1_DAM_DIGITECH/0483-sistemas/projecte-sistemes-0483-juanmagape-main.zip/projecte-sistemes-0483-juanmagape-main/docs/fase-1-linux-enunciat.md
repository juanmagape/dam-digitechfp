# FASE 1

# Enunciat i lliurament d'evidències de la FASE 1

### Objectiu

L'objectiu d'aquest lliurament és demostrar que:

- la màquina virtual s'ha creat correctament
- Ubuntu Server s'ha instal·lat correctament
- la configuració de discos és correcta
- el sistema arrenca correctament
- la xarxa funciona
- l'accés SSH funciona

---

## Carpeta de lliurament

Entrar a la carpeta del repositori (**`~/projecte-sistemes-0483-<github_user>`**).

## Comanda a executar

```bash
cd projecte-sistemes-0483-<github_user>/
```

En el meu cas:
<pre>
administrador@srv-sistemes-0483:~$ cd
administrador@srv-sistemes-0483:~$ ls
projecte-sistemes-0483-jpardo20
administrador@srv-sistemes-0483:~$ cd projecte-sistemes-0483-jpardo20/
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>

## Comanda a executar EN EL MEU CAS!!!

```bash
cd projecte-sistemes-0483-jpardo20/
```

# Cal que modifiqueu **`jpardo20`** pel vostre **`<github_user>`**

Cal crear la carpeta **`evidencies/fase-1/`**.

## Comanda a executar

```bash
mkdir -p evidencies/fase-1/
```

<pre>
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ mkdir -p evidencies/fase-1/
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ ls -ld evidencies/fase-1/
drwxrwxr-x 2 administrador administrador 4096 jan 10 00:00 evidencies/fase-1/
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>



Dins d'aquesta carpeta (**`evidencies/fase-1/`**) caldrà afegir:

- el document **`evidencies/fase-1/lliurament.md`** a on haureu d'anar explicant cadascuna de les comandes que executeu, i 

- tots els fitxers de les evidències demanades.


> No cal explicar els símbols del terminal ni les rutes mostrades automàticament.

---

## Evidència 1: Discos i particions

### Objectiu

Mostra tots els discos i les particions que té el servidor.

### Comanda a explicar **`lsblk`**

Cal que dins del document **`evidencies/fase-1/lliurament.md`** expliqueu que fa aquesta comanda.

### Fitxer a generar: **`evidencies/fase-1/lsblk.txt`**

## Comanda a executar

Per generar el fitxer d'aquesta evidència cal que executeu la següent comanda:

```bash
lsblk > evidencies/fase-1/lsblk.txt
```

NOTA: El símbol **`>`** redirigeix la sortida de la comanda a un fitxer.

<pre>
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git status
On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ lsblk > evidencies/fase-1/lsblk.txt
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git status
On branch main
Your branch is up to date with 'origin/main'.

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        evidencies/fase-1/

nothing added to commit but untracked files present (use "git add" to track)
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>

---

## Evidència 2: Xarxa

### Objectiu

Mostra la configuració de totes les interfícies de xarxa que té el servidor.

### Comanda a explicar **`ip a`**

Cal que dins del document **`evidencies/fase-1/lliurament.md`** expliqueu que fa aquesta comanda.

### Fitxer a generar: **`evidencies/fase-1/ip-a.txt`**

## Comanda a executar

```bash
ip a > evidencies/fase-1/ip-a.txt
```

---

## Evidència 3: Informació del sistema

### Objectiu

Esbrinar un seguit de detalls del servidor.

### Comanda a explicar **`hostnamectl`**

### Fitxer a generar: **`evidencies/fase-1/hostnamectl.txt`**

## Comanda a executar

```bash
hostnamectl > evidencies/fase-1/hostnamectl.txt
```

---

## Evidència 4: Sistemes de fitxers muntats

### Objectiu

Conèixer els diferents punts de muntatge que té el servidor, i sobre quins dispositius s'han muntat.

### Comanda a explicar **`mount`**

### Fitxer a generar: **`evidencies/fase-1/mount.txt`**

## Comanda a executar

```bash
mount > evidencies/fase-1/mount.txt
```

---

## Evidència 5: Accés SSH

### Objectiu

Demostrar que es pot accedir remotament al servidor.

---

### Comanda a explicar **`ssh`**


## Comanda a executar

Executar des del sistema host:

```bash
ssh administrador@IP hostname
```

Substituir **`IP`** per la **`IP Host-only`** de la vostra màquina virtual.

---

### Fitxer a generar: **`evidencies/fase-1/ssh-ok.txt`**

El fitxer ha de contenir el nom del servidor (`srv-sistemes-0483`).

## Comanda a executar

```bash
ssh administrador@<IP SERVIDOR> hostname > evidencies/fase-1/ssh-ok.txt
```

<pre>
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ ssh administrador@192.168.56.XXX hostname > evidencies/fase-1/ssh-ok.txt
administrador@192.168.56.XXX's password: 
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>

---


## Evidència 6: Historial de comandes

### Objectiu

Obtenir l'historial de comandes utilitzades durant la fase.

### Comanda a explicar **`history`**

### Fitxer a generar: **`evidencies/fase-1/history.txt`**

## Comanda a executar

```bash
history > evidencies/fase-1/history.txt
```

<pre>
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ history > evidencies/fase-1/history.txt
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>


## Evidència 7 - Resum tècnic

### Objectiu

Demostrar que heu entés tots els passos que hem dut a terme i que sou capaços d'explicar-los amb les vostres paraules.

### Fitxer a generar: **`evidencies/fase-1/lliurament.md`**

---

### Contingut mínim

Explicació:

- de les 7 evidències que se us han demanat,
- indicar, si s'escau, amb quins problemes us heu trobat,
- indicar, si heu detectat algun error, i com s'han solucionat

---

## Estructura final esperada

```bash
~/projecte-sistemes-0483-jpardo20
├── docker
├── docs
│   ├── fase-1-linux.md
│   ├── fase-1-linux-enunciat.md
│   └── img
├── evidencies
│   └── fase-1
│       ├── hostnamectl.txt
│       ├── ip-a.txt
│       ├── lsblk.txt
│       ├── mount.txt
│       ├── ssh-ok.txt
│       ├── history.txt
│       └── lliurament.md
├── prova.txt
├── README.md
└── scripts
```

---

## Lliurament final

Quan tot estigui completat:

Per veure els fitxer que hem creat i cal afegir al següent **`commit`**.

```bash
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git status --untracked-files=all
On branch main
Your branch is up to date with 'origin/main'.

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        evidencies/fase-1/lliurament.md
        evidencies/fase-1/hostnamectl.txt
        evidencies/fase-1/ip-a.txt
        evidencies/fase-1/lsblk.txt
        evidencies/fase-1/mount.txt
        evidencies/fase-1/ssh-ok.txt
        evidencies/fase-1/history.txt

nothing added to commit but untracked files present (use "git add" to track)
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
```


### Comandes a executar

Ara cal executar

```bash
git add evidencies/fase-1/lliurament.md \
    evidencies/fase-1/hostnamectl.txt \
    evidencies/fase-1/ip-a.txt \
    evidencies/fase-1/lsblk.txt \
    evidencies/fase-1/mount.txt \
    evidencies/fase-1/ssh-ok.txt \
    evidencies/fase-1/history.txt
git commit -m "Lliurament fase 1"
git push
```

Si **`git push`** falla temporalment amb **errors SSH** o **`Broken pipe`**, simplement torna a executar la comanda.

```bash
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git push
client_loop: send disconnect: Broken pipe
fatal: Could not read from remote repository.

Please make sure you have the correct access rights
and the repository exists.
```

---

<pre>
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git add evidencies/fase-1/lliurament.md \
    evidencies/fase-1/hostnamectl.txt \
    evidencies/fase-1/ip-a.txt \
    evidencies/fase-1/lsblk.txt \
    evidencies/fase-1/mount.txt \
    evidencies/fase-1/ssh-ok.txt \
    evidencies/fase-1/history.txt
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git status
On branch main
Your branch is up to date with 'origin/main'.

Changes to be committed:
  (use "git restore --staged <file>..." to unstage)
        new file:   evidencies/fase-1/lliurament.md
        new file:   evidencies/fase-1/hostnamectl.txt
        new file:   evidencies/fase-1/ip-a.txt
        new file:   evidencies/fase-1/lsblk.txt
        new file:   evidencies/fase-1/mount.txt
        new file:   evidencies/fase-1/ssh-ok.txt
        new file:   evidencies/fase-1/history.txt
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git commit -m "Lliurament fase 1"
[main a5704c5] Lliurament fase 1
 7 files changed, 69 insertions(+)
 create mode 100644 evidencies/fase-1/lliurament.md
 create mode 100644 evidencies/fase-1/hostnamectl.txt
 create mode 100644 evidencies/fase-1/ip-a.txt
 create mode 100644 evidencies/fase-1/lsblk.txt
 create mode 100644 evidencies/fase-1/mount.txt
 create mode 100644 evidencies/fase-1/ssh-ok.txt
 create mode 100644 evidencies/fase-1/history.txt
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ git push
Enumerating objects: 13, done.
Counting objects: 100% (13/13), done.
Delta compression using up to 2 threads
Compressing objects: 100% (9/9), done.
Writing objects: 100% (10/10), 2.11 KiB | 360.00 KiB/s, done.
Total 10 (delta 1), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (1/1), completed with 1 local object.
To github.com:DAM-2025-2027/projecte-sistemes-0483-jpardo20.git
   e437b09..a5704c5  main -> main
administrador@srv-sistemes-0483:~/projecte-sistemes-0483-jpardo20$ 
</pre>


---

## Resultat esperat

Al final de la fase cal tenir:

- Ubuntu Server funcional
- sistema arrencant correctament
- accés SSH operatiu
- estructura de discos correcta
- evidències pujades al repositori
