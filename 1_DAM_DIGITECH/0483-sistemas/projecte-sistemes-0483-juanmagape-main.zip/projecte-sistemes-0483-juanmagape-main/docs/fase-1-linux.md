# FASE 1 — Linux + Setup inicial

## Objectiu

- Crear la màquina virtual correctament
- Instal·lar Ubuntu Server
- Preparar entorn de treball (SSH + Git)
- Clonar el repositori del projecte

---

## Missió

Has d’aconseguir una MV Ubuntu Server amb:

- **`2` CPU**
- **`4` GB RAM**
- **`4` discos**
- **`3` NICs**
- Ubuntu instal·lat només al disc 1
- **`/`** de **`18 GB`**
- **`swap`** amb l’**espai restant**
- **`OpenSSH`** instal·lat
- usuari **`administrador`**

---

# 1. Configuració de la màquina virtual

## Paràmetres

- Nom: srv-sistemes-0483
- CPU: 2 cores
- RAM: 4 GB

---

## Discos

- Disc 1 → **`20GB`** → **`Sistema`** (**`/`** + **`swap`**)
- Disc 2 → **`20GB`** → **`RAID 5`**
- Disc 3 → **`20GB`** → **`RAID 5`**
- Disc 4 → **`20GB`** → **`RAID 5`**

> **IMPORTANT:**
> Només treballarem amb el primer disc (**`20GB`**)
> No tocar, ni modificar cap dels discos 2, 3 i 4

---

## Xarxa

- NIC 1 → NAT
- NIC 2 → Host-only
- NIC 3 → Bridge (de moment no la farem servir)


---

## Objectiu de la fase:

- Instal·lar Ubuntu
- Crear:
  - **`/`** (**`18GB`**)
  - **`swap`** (**`~2GB`**)
- Només al disc 1

---

# 2. Instal·lació Ubuntu Server (1/24)

A la finestra **`Actualización del instalador disponible`**, saltar a **`Continuar sin actualizar`**

Aquest pas evita descarregar una versió nova de l’instal·lador i ajuda a fer la instal·lació més ràpida i estable a l’aula.

![alt text](./img/continuar-sin-actualizar.png)

---

# 2. Instal·lació Ubuntu Server (2/24)

Seleccionar: **`Ubuntu Server`**

![alt text](./img/seleccionar-ubuntu-server.png)

----


# 2. Instal·lació Ubuntu Server (3/24)

A la pantalla `Ubuntu archive mirror configuration`, no cal esperar cap comprovació addicional.

Prem directament **`[ Hecho ]`**.

![alt text](./img/stop-archive-mirror-configuration.png)


# 2. Instal·lació Ubuntu Server (4/24)

Apunta:

- **`enp0s3`**,
- **`enp0s8`**,
- **`enp0s9`**, i 
- **IP** de **`enp0s8`** (**`192.168.56.X`**)

![alt text](./img/les-3-nic-enp0s3-enp0s8-enp0s9.png)


---

# 2. Instal·lació Ubuntu Server (5/24)

Deixar **`Proxy address`** en blanc.

![alt text](./img/proxy-address-en-blanc.png)

---

# 2. Instal·lació Ubuntu Server (6/24)

Molt important!!

A la finestra **`Guided storage configuration`** escollir:

**`(x) Custom storage layout`**

![alt text](./img/custom-storage-layout.png)

---

# 2. Instal·lació Ubuntu Server (7/24)

### IMPORTANT: Seleccionar el disc 1 i marcar-lo com a dispositiu d’arrencada (boot device)

Abans de fer res, cal indicar al SO quin és el disc que farem servir com a disc d'arrencada (**`Boot device`**).

Per fer-ho, cal que a la pantalla **`Storage configuration`** selecciona el disc en qüestió, en aquest cas el primer que té el nom **`VBOX_HARDDISK`**, que pitgem el triangle que hi ha, i al menú que apareix seleccionem **`Use As Boot Device`** (**Fer servir com a dispositu d'arrencada.**)

![alt text](./img/use-as-boot-device.png)

---

# 2. Instal·lació Ubuntu Server (8/24)

Ara creeu una partició de **`18GB`** amb **`/`** pel SO i després en fem una de **`swap`** amb el que queda.

### Crear la primera partició (SO)

Seleccionarem el primer dels discos que té el nom **`VBOX_HARDDISK`**, el que hem marcat com a **`boot device`**.

És a dir, el primer de 20GB.

![alt text](./img/primera-particio-20-gb.png)

---

# 2. Instal·lació Ubuntu Server (9/24)

D'aquest primer disc, seleccionem la segona opció, la de **`espacio disponible`**, pitgem el triangle que hi ha, i del menú que apareix, seleccionem l'opció **`Add GPT Partition`**.

![alt text](./img/add-gpt-partition.png)

---

# 2. Instal·lació Ubuntu Server (10/24)

Dins de la pantalla **`Storage configuration`** a la secció **`Adding GPT Partition`** cal que omplis:

**Size: `18G`**

**Format: `ext4`**

**Mount: `/`**

**Acció: `[Crear   ]`**

![alt text](./img/adding-a-gpt-partition.png)

---

# 2. Instal·lació Ubuntu Server (11/24)

Després d'això veureu:

> **Disc 1** amb una **partició `/`**
> quedarà espai lliure **`~2GB`**

![alt text](./img/espai-lliure-aprox-2-gb.png)

---

# 2. Instal·lació Ubuntu Server (12/24)

### Crear la segona partició (swap)

Una altra vegada, de la segona opció, la de **`espacio disponible`**, i del menú que apareix, l'opció **`Add GPT Partition`**

![alt text](./img/swap-partition.png)

**Size: `deixar per defecte (tot l'espai restant)`**

**Format: `swap`**

**Mount: ``**

**Acció: `[Crear   ]`**

---

# 2. Instal·lació Ubuntu Server (13/24)

![alt text](./img/storage-configuration-summary.png)

| Partició | Mida | Ús |
|---|---:|---|
| partition 1 | 1 MB | BIOS grub spacer |
| partition 2 | 18 GB | `/` |
| partition 3 | ~2 GB | `swap` |

---

Abans de seguir, cal confirmar que el disc que hem configurat apareix com a disc d'arrencada (**`Boot device`**).

Per fer-ho, seleccionem el primer que té el nom **`VBOX_HARDDISK`**, que pitgem el triangle que hi ha, i al menú que apareix ha d'aparèixer **`Add As Another Boot Device`**. Això indica que ja l'hem configurat com a disc d'arrencada.

![alt text](./img/add-as-another-boot-device.png)

---

# 2. Instal·lació Ubuntu Server (14/24)

![alt text](./img/storage-configuration-summary-detall.png)

Comprovem el que tenim:

**`partition 1`** de **`1 MB`**, per **`GRUB`** (Gestor d'arrencada de Linux),
**`partition 2`** de **`18 GB`**, muntat a **`/`** pel sistema operatiu, i
**`partition 3`** de **`1.997GB`**, pel fitxer de paginació **`swap`**.

La partició (**`partition 1`**) és necessària per arrencar el sistema.

---

## Abans de continuar, comprova:

- Tens una partició `/`
- Tens una partició `swap`
- Només has utilitzat el disc 1
- El disc 1 apareix com a `Boot device`
- Els discos 2, 3 i 4 continuen buits

Si tot és correcte, continua.

---

# 2. Instal·lació Ubuntu Server (15/24)

A la finestra de **`Confirmar acción destructiva`**, confirmem que acceptem perdre tota la informació que hi pugui haver al disc seleccionat.
**Acció: `[Continuar   ]`**


![alt text](./img/confirmar-accion-destructiva.png)

---

# 2. Instal·lació Ubuntu Server (16/24)

![alt text](./img/profile-configuration.png)

**Su nombre: `administrador`**

**Your server name: `srv-sistemes-0483`**

**Elija un nombre de usuario: `administrador`**

**Elija una contraseña: `admin123`**

**Confirme la contraseña: `admin123`**

**Acció: `[Hecho   ]`**

---

# 2. Instal·lació Ubuntu Server (17/24)

A la finestra **`Upgrade to ubuntu Pro`** escollir:

**`(X) Skip for now`**

**Acció: `[Continuar   ]`**

![alt text](./img/skip-upgrade-to-ubuntu-pro.png)

---

# 2. Instal·lació Ubuntu Server (18/24)

A la finestra **`SSH configuration`** escollir:

> ## Opció MOLT important

Cal seleccionar:

**`[X] Install OpenSSH server`**

**Acció: `[Hecho   ]`**

![alt text](./img/ssh-configuration.png)

---

# 2. Instal·lació Ubuntu Server (19/24)

A la finestra **`Featured server snaps`** no marcar res.

**Acció: `[Hecho   ]`**

![alt text](./img/featured-server-snaps.png)

---

# 2. Instal·lació Ubuntu Server (20/24)

Mostra de captura durant la instal·lació d'ubuntu server

![alt text](./img/captura-durant-la-instal-lacio.png)

---

# 2. Instal·lació Ubuntu Server (21/24)

Un cop ja ha acabat la instal·lació, apareix l'opció **`[ Reiniciar ahora ]`**

![alt text](./img/captura-reinicar-ahora.png)

---

# 2. Instal·lació Ubuntu Server (22/24)

I a continuació apareix un missatge que ens indica que cal retirar el CD amb que s'ha fet la instal·lació i pressionar ENTER.

Pressionem **`ENTER`** per seguir, ja que en tractar-se d'una MV el dispositiu ja s'ha desactivat.

![alt text](./img/retirar-cd-i-pressionar-enter.png)

---

# 2. Instal·lació Ubuntu Server (23/24)

I ja apareix la pantalla que ens demana que entrem l'usuari:

**`login: administrador`** i

**`Password: admin123`**

![alt text](./img/primer-login-administrador.png)

---

# 2. Instal·lació Ubuntu Server (24/24)

I ja estem a la consola del nostre servidor amb una sessió connectada amb l'usuari **`administrador`** que hem creat.

![alt text](./img/consola-primera-sessio-usuari-administrador.png)

---

Comprova abans de continuar:

✔ Tens una partició /
✔ Tens una partició swap
✔ Només has utilitzat el disc 1
✔ Has marcat el disc com a boot device

---

# 3. Primer arrencada

## Actualitzar sistema

```bash
sudo apt update
sudo apt upgrade -y
```

---

## Comprovar IP

```bash
ip a
```

Identificar:
- interfície NAT
- interfície Host-only

---

# 4. Accés remot

Des del PC host:

```bash
ssh administrador@IP
```

---

# 5. Instal·lació Git

```bash
sudo apt install git -y
```

---

## Configurar usuari Git

```bash
git config --global user.name "Nom Alumne"
git config --global user.email "email@exemple.com"
```

---

# 6. Configurar accés a GitHub amb SSH

## Generar clau

```bash
ssh-keygen -t ed25519
```

---

## Mostrar clau

```bash
cat ~/.ssh/id_ed25519.pub
```

Afegir aquesta clau a GitHub (Settings → SSH keys)

---

# 7. Clonar repositori del projecte

```bash
git clone git@github.com:USUARI/projecte-sistemes-0483.git
```

---

## Entrar al projecte

```bash
cd projecte-sistemes-0483
```

---

# 8. Primera prova

```bash
touch prova.txt
git add .
git commit -m "Primera prova"
git push
```

---

# Errors típics

- SSH no funciona → comprovar que OpenSSH està instal·lat
- Git demana password → comprovar configuració SSH i URL del repo
- No es pot connectar → revisar IP i xarxa Host-only

---

# Resultat final

- MV funcionant
- Accés SSH correcte
- Git configurat
- Repositori clonat
