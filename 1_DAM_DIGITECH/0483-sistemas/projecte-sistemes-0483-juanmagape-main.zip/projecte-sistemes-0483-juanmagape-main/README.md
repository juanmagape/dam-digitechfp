# Projecte 0483 - Sistemes Informàtics

## Desplegament d’un servidor Linux amb Docker

## Objectiu

Construir un sistema complet que inclogui:

* Sistema Linux
* Xarxa funcional
* Servei amb Docker
* Monitorització
* Automatització


## Fases del projecte

1. [Linux (instal·lació i configuració)](./docs/fase-1-linux.md)
2. Xarxa
3. Docker
4. Monitorització
5. Automatització


## Entregues

Aquest repositori s’anirà completant durant el projecte.

Caldrà documentar:

* configuració del sistema
* comandes utilitzades
* captures de pantalla
* explicacions


## Estructura

* docs/ → documentació per fases
* scripts/ → scripts creats
* docker/ → configuració de contenidors
* evidencies/ → captures


## Avaluació

* Funcionament del sistema
* Qualitat de la documentació
* Capacitat d’explicació
* Extres implementats

## Enunciats i lliuraments

### [Enunciat de la FASE 1](./docs/fase-1-linux-enunciat.md)
