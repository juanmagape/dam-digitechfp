## Evidencia 1: Configuración de red

Explicación del comando:
El comando `ip a` muestra las tarjetas de red (interfaces) disponibles en el servidor y las direcciones IP que tienen asignadas.

Comando realizado:

* `ip a > evidencies/fase-2/ip-a.txt`

Salida del comando:

```text
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000 
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 
    inet 127.0.0.1/8 scope host lo 
       valid_lft forever preferred_lft forever 
    inet6 ::1/128 scope host noprefixroute  
       valid_lft forever preferred_lft forever 
2: enp0s3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000 
    link/ether 08:00:27:de:6b:f5 brd ff:ff:ff:ff:ff:ff 
    inet 10.0.2.15/24 metric 100 brd 10.0.2.255 scope global dynamic enp0s3 
       valid_lft 85404sec preferred_lft 85404sec 
    inet6 fd17:625c:f037:2:a00:27ff:fede:6bf5/64 scope global dynamic mngtmpaddr noprefixroute  
       valid_lft 86031sec preferred_lft 14031sec 
    inet6 fe80::a00:27ff:fede:6bf5/64 scope link  
       valid_lft forever preferred_lft forever 
3: enp0s8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000 
    link/ether 08:00:27:d4:c7:2d brd ff:ff:ff:ff:ff:ff 
    inet 192.168.56.107/24 metric 100 brd 192.168.56.255 scope global dynamic enp0s8 
       valid_lft 504sec preferred_lft 504sec 
    inet6 fe80::a00:27ff:fed4:c72d/64 scope link  
       valid_lft forever preferred_lft forever 
4: enp0s9: <BROADCAST,MULTICAST,UP,LOWER_UP>  
mtu 1500 qdisc fq_codel state UP group default qlen 1000 
    link/ether 08:00:27:81:f0:31 brd ff:ff:ff:ff:ff:ff 
    inet 192.168.1.48/24 metric 100 brd 192.168.1.255 scope global dynamic enp0s9 
       valid_lft 42206sec preferred_lft 42206sec 
    inet6 fe80::a00:27ff:fe81:f031/64 scope link  
       valid_lft forever preferred_lft forever 

```

## Evidencia 2: Tabla de enrutamiento

Explicación del comando:
Nos permite ver la tabla de enrutamiento del servidor, indicando la puerta de enlace por defecto y las rutas para alcanzar las distintas redes.

Comando realizado:

* `ip route > evidencies/fase-2/ip-route.txt`

Salida del comando:

```text
default via 10.0.2.2 dev enp0s3 proto dhcp src 10.0.2.15 metric 100  
default via 192.168.1.1 dev enp0s9 proto dhcp src 192.168.1.48 metric 100  
10.0.2.0/24 dev enp0s3 proto kernel scope link src 10.0.2.15 metric 100  
10.0.2.2 dev enp0s3 proto dhcp scope link src 10.0.2.15 metric 100  
10.29.0.1 via 192.168.1.1 dev enp0s9 proto dhcp src 192.168.1.48 metric 100  
80.58.61.250 via 10.0.2.2 dev enp0s3 proto dhcp src 10.0.2.15 metric 100  
80.58.61.250 via 192.168.1.1 dev enp0s9 proto dhcp src 192.168.1.48 metric 100  
80.58.61.254 via 10.0.2.2 dev enp0s3 proto dhcp src 10.0.2.15 metric 100  
80.58.61.254 via 192.168.1.1 dev enp0s9 proto dhcp src 192.168.1.48 metric 100  
192.168.1.0/24  
dev enp0s9 proto kernel scope link src 192.168.1.48 metric 100  
192.168.1.1 dev enp0s9 proto dhcp scope link src 192.168.1.48 metric 100  
192.168.56.0/24 dev enp0s8 proto kernel scope link src 192.168.56.107 metric 100 

```

## Evidencia 3: Conectividad a Internet (NAT)

Explicación del comando:
Enviamos paquetes al dominio de Google para verificar que la máquina virtual tiene conexión funcional hacia Internet.

Comando realizado:

* `ping -c 4 google.com > evidencies/fase-2/ping-google.txt`

Salida del comando:

```text
PING google.com (216.58.204.206) 56(84) bytes of data. 
64 bytes from bru06s02-in-f14.1e100.net (216.58.204.206): icmp_seq=1 ttl=255 time=20.7 ms 
64 bytes from bru06s02-in-f14.1e100.net (216.58.204.206): icmp_seq=2 ttl=116 time=21.9 ms 
64 bytes from bru06s02-in-f14.1e100.net (216.58.204.206): icmp_seq=3 ttl=255 time=21.4 ms 
64 bytes from bru06s02-in-f14.1e100.net (216.58.204.206): icmp_seq=4 ttl=116 time=31.4 ms 

--- google.com ping statistics --- 
4 packets transmitted, 4 received, 0% packet loss, time 3053ms 
rtt min/avg/max/mdev = 20.748/23.871/31.396/4.364 ms 

```

## Evidencia 4: Conectividad Host-Only

Explicación del comando:
Comprobamos la conectividad ejecutando un ping desde el Host hacia la IP de la red Host-Only de la máquina virtual (192.168.56.107).

Comando realizado:

* `ping -n 4 192.168.56.107 > evidencies/fase-2/ping-host-only.txt`

Salida del comando:

```text
C:\Users\Admin>ping -n 4 192.168.56.107 

Haciendo ping a 192.168.56.107 con 32 bytes de datos: 
Respuesta desde 192.168.56.107: bytes=32 tiempo<1m TTL=64 
Respuesta desde 192.168.56.107: bytes=32 tiempo<1m TTL=64 
Respuesta desde 192.168.56.107: bytes=32 tiempo=1ms TTL=64 
Respuesta desde 192.168.56.107: bytes=32 tiempo<1m TTL=64 

Estadísticas de ping para 192.168.56.107: 
    Paquetes: enviados = 4, recibidos = 4, perdidos = 0 
    (0% perdidos), 
Tiempos aproximados de ida y vuelta en milisegundos: 
    Mínimo = 0ms, Máximo = 1ms, Media = 0ms 

C:\Users\Admin> 

```

## Evidencia 5: Puertos a la escucha

Explicación del comando:
Muestra el estado de los puertos de red. Permite ver qué servicios están activos y "escuchando" conexiones entrantes en nuestro servidor.

Comando realizado:

* `sudo ss -tulpn > evidencies/fase-2/ss-tulpn.txt`

Salida del comando:

```text
Netid State  Recv-Q Send-Q                     Local Address:Port Peer Address:PortProcess                                                 
udp   UNCONN 0      0               
               127.0.0.54:53        0.0.0.0:* users:(("systemd-resolve",pid=479,fd=16))              
udp   UNCONN 0      0                          127.0.0.53%lo:53        0.0.0.0:* users:(("systemd-resolve",pid=479,fd=14))             
  
udp   UNCONN 0      0                  192.168.56.107%enp0s8:68        0.0.0.0:* users:(("systemd-network",pid=460,fd=19))              
udp   UNCONN 0      0                    192.168.1.48%enp0s9:68        0.0.0.0:* users:(("systemd-network",pid=460,fd=30))     
          
udp   UNCONN 0      0                       10.0.2.15%enp0s3:68        0.0.0.0:* users:(("systemd-network",pid=460,fd=22))              
udp   UNCONN 0      0      [fe80::a00:27ff:fe81:f031]%enp0s9:546          [::]:* users:(("systemd-network",pid=460,fd=29))    
           
tcp   LISTEN 0      4096                       127.0.0.53%lo:53        0.0.0.0:* users:(("systemd-resolve",pid=479,fd=15))              
tcp   LISTEN 0      4096                       
       0.0.0.0:22        0.0.0.0:* users:(("sshd",pid=1107,fd=3),("systemd",pid=1,fd=90)) 
tcp   LISTEN 0      4096                          127.0.0.54:53        0.0.0.0:* users:(("systemd-resolve",pid=479,fd=17))              
tcp   LISTEN 0      4096           
                      [::]:22           [::]:* users:(("sshd",pid=1107,fd=4),("systemd",pid=1,fd=91)) 

```

## Evidencia 6.1: Verificar el puerto 8080

Explicación del comando:
Comprueba si hay algún servicio utilizando el puerto 8080. Filtra la información (con `grep`) para mostrar que el puerto está en estado de escucha y el proceso que lo utiliza es Python.

Comando realizado:

* `sudo ss -tulpn | grep 8080 > evidencies/fase-2/port-8080.txt`

Salida del comando:

```text
tcp   LISTEN 0      5                                0.0.0.0:8080      0.0.0.0:* users:(("python3",pid=1434,fd=3)) 

```

## Evidencia 7: Acceso web desde el host

Explicación del comando:
El comando `curl` hace una petición web por terminal al puerto especificado (8080). Sirve para demostrar que el servicio HTTP responde correctamente entregando el contenido de la página.

Comando realizado:

* `curl http://192.168.56.107:8080 > evidencies/fase-2/curl-web.txt`

Salida del comando:

```text
C:\Users\Admin>curl http://192.168.56.107:8080 
<h1>Servidor OK</h1> 
C:\Users\Admin> 

```

## Evidencia 8: Historial de comandos

Explicación del comando:
Genera una lista con todo el registro de comandos introducidos durante la sesión. Es útil en administración de sistemas para documentar, auditar qué se ha tocado o reproducir fácilmente los procesos.

Comando realizado:

* `history > evidencies/fase-2/history.txt`

Salida del comando:

```text
    1  exit 
    2  ls 
    3  cd projecte-sistemes-0483-juanmagape/ 
    4  ls 
    5  cd evidencies/ 
    6  cd fase- 
    7  cd fase-2 
    8  ls 
    9  cat ping-host-only.txt  
   10  rm ping-host-only.txt  
   11  touch ping-host-only.txt 
   12  nano ping-host-only.txt  
   13  mkdir -p ~/web-test 
   14  ls 
   15  cd 
   16  cd ~/web-test 
   17  echo "<h1>Servidor OK</h1>" > index.html 
   18  sudo ss -tulpn | grep 8080 > evidencies/fase-2/port-8080.txt 
   19  cd 
   20  ls 
   21  cd projecte-sistemes-0483-juanmagape/ 
   22  ls 
   23  cd evidencies/ 
   24  ls 
   25  cd .. 
   26  sudo ss -tulpn | grep 8080 > evidencies/fase-2/port-8080.txt 
   27  ls 
   28  cd evidencies/ 
   29  ls 
   30  cd fase-2 
   31  ls 
   32  cat port-8080.txt  
   33  touch curl-web.txt 
   34  nano curl-web.txt  
   35  history > evidencies/fase-2/history.txt 
   36  cd .. 
   37  history > evidencies/fase-2/history.txt 

```