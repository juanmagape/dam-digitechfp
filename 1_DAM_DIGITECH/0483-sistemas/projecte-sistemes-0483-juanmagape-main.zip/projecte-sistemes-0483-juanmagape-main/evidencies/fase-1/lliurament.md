## Evidència 1: Discos i particions

Explicación del comando:

El comando lsblk nos muestra las particiones y discos que tenemos en el sistema, juntamente con el espacio asignado para cada uno, el tipo (si es disco o partición), juntamente con el punto de montura, por ejemplo el disco que tiene el sistema principal, tiene asignado el punto de montura de raíz (/).

---

Comando realizado:

* lsblk > evidencies/fase-1/lsblk.txt



---

Salida del comando:

```
NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINTS
sda      8:0    0   20G  0 disk
├─sda1   8:1    0    1M  0 part
├─sda2   8:2    0   18G  0 part /
└─sda3   8:3    0    2G  0 part [SWAP]
sdb      8:16   0   20G  0 disk
sdc      8:32   0   20G  0 disk
sdd      8:48   0   20G  0 disk
sr0     11:0    1 1024M  0 rom

```

## Evidència 2: Xarxa

Explicación del comando:

Con este comando podemos ver la configuración de red. Nos muestra las tarjetas de red (interfaces) que tiene el servidor y las direcciones IP que tienen asignadas.

---

Comando realizado:

* ip a > evidencies/fase-1/ip-a.txt



---

Salida del comando:

```
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute
       valid_lft forever preferred_lft forever
2: enp0s3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 08:00:27:de:6b:f5 brd ff:ff:ff:ff:ff:ff
    inet 10.0.2.15/24 metric 100 brd 10.0.2.255 scope global dynamic enp0s3
       valid_lft 85704sec preferred_lft 85704sec
    inet6 fd17:625c:f037:2:a00:27ff:fede:6bf5/64 scope global dynamic mngtmpaddr noprefixroute
       valid_lft 86286sec preferred_lft 14286sec
    inet6 fe80::a00:27ff:fede:6bf5/64 scope link
       valid_lft forever preferred_lft forever
3: enp0s8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 08:00:27:d4:c7:2d brd ff:ff:ff:ff:ff:ff
    inet 192.168.56.102/24 metric 100 brd 192.168.56.255 scope global dynamic enp0s8
       valid_lft 504sec preferred_lft 504sec
    inet6 fe80::a00:27ff:fed4:c72d/64 scope link
       valid_lft forever preferred_lft forever
4: enp0s9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 08:00:27:81:f0:31 brd ff:ff:ff:ff:ff:ff
    inet 192.168.8.59/22 metric 100 brd 192.168.11.255 scope global dynamic enp0s9
       valid_lft 1106sec preferred_lft 1106sec
    inet6 fe80::a00:27ff:fe81:f031/64 scope link
       valid_lft forever preferred_lft forever

```

## Evidència 3: Informació del sistema

Explicación del comando:

Este comando da un resumen de la información del sistema. Sirve para ver el nombre de la máquina, qué versión exacta de Ubuntu Server tenemos instalada, el kernel y detalles de la máquina virtual.

---

Comando realizado:

* hostnamectl > evidencies/fase-1/hostnamectl.txt



---

Salida del comando:

```
Static hostname: srv-sistemes-0483
       Icon name: computer-vm
         Chassis: vm 🖴
      Machine ID: ab012f32fd2e4cb3811dda2e4d9e0122
         Boot ID: 7b9e38bc43814f28a46dea046909879a
  Virtualization: oracle
Operating System: Ubuntu 24.04.4 LTS
          Kernel: Linux 6.8.0-111-generic
    Architecture: x86-64
 Hardware Vendor: innotek GmbH
  Hardware Model: VirtualBox
Firmware Version: VirtualBox
   Firmware Date: Fri 2006-12-01
    Firmware Age: 19y 5month 1w 5d

```

## Evidència 4: Sistemes de fitxers muntats

Explicación del comando:

Comando para ver todos los sistemas de archivos que están montados en este momento. dice qué dispositivos o discos están conectados y en qué carpetas (puntos de montaje).

---

Comando realizado:

* mount > evidencies/fase-1/mount.txt



---

Salida del comando:

```
sysfs on /sys type sysfs (rw,nosuid,nodev,noexec,relatime)
proc on /proc type proc (rw,nosuid,nodev,noexec,relatime)
udev on /dev type devtmpfs (rw,nosuid,relatime,size=1963220k,nr_inodes=490805,mode=755,inode64)
devpts on /dev/pts type devpts (rw,nosuid,noexec,relatime,gid=5,mode=620,ptmxmode=000)
tmpfs on /run type tmpfs (rw,nosuid,nodev,noexec,relatime,size=400996k,mode=755,inode64)
/dev/sda2 on / type ext4 (rw,relatime)
securityfs on /sys/kernel/security type securityfs (rw,nosuid,nodev,noexec,relatime)
tmpfs on /dev/shm type tmpfs (rw,nosuid,nodev,inode64)
tmpfs on /run/lock type tmpfs (rw,nosuid,nodev,noexec,relatime,size=5120k,inode64)
cgroup2 on /sys/fs/cgroup type cgroup2 (rw,nosuid,nodev,noexec,relatime,nsdelegate,memory_recursiveprot)
pstore on /sys/fs/pstore type pstore (rw,nosuid,nodev,noexec,relatime)
bpf on /sys/fs/bpf type bpf (rw,nosuid,nodev,noexec,relatime,mode=700)
systemd-1 on /proc/sys/fs/binfmt_misc type autofs (rw,relatime,fd=32,pgrp=1,timeout=0,minproto=5,maxproto=5,direct,pipe_ino=4275)
hugetlbfs on /dev/hugepages type hugetlbfs (rw,nosuid,nodev,relatime,pagesize=2M)
mqueue on /dev/mqueue type mqueue (rw,nosuid,nodev,noexec,relatime)
debugfs on /sys/kernel/debug type debugfs (rw,nosuid,nodev,noexec,relatime)
tracefs on /sys/kernel/tracing type tracefs (rw,nosuid,nodev,noexec,relatime)
fusectl on /sys/fs/fuse/connections type fusectl (rw,nosuid,nodev,noexec,relatime)
configfs on /sys/kernel/config type configfs (rw,nosuid,nodev,noexec,relatime)
binfmt_misc on /proc/sys/fs/binfmt_misc type binfmt_misc (rw,nosuid,nodev,noexec,relatime)
tmpfs on /run/user/1000 type tmpfs (rw,nosuid,nodev,relatime,size=400992k,nr_inodes=100248,mode=700,uid=1000,gid=1000,inode64)

```

## Evidència 5: Accés SSH

Explicación del comando:

Comando que nos sirve para conectarnos a nuestro servidor desde nuestro portatil, mediante el servicio OpenSSH que se instala al crear la maquina virtual

---

Comando realizado:

* ssh administrador@192.168.56.102 hostname > evidencies/fase-1/ssh-ok.txt



---

Salida del comando:

```
srv-sistemes-0483

```

## Evidència 6: Historial de comandes

Explicación del comando:

este comando es una lista numerada con todos los comandos que hemos ido metiendo en la consola.

---

Comando realizado:

* history > evidencies/fase-1/history.txt



---

Salida del comando:

```
    1  cd projecte-sistemes-0483-juanmagape/
    2  ls
    3  mkdir -p evidencies/fase-1/
    4  cd evidencies/fase-1/
    5  touch lliurament.md
    6  lsblk
    7  lsblk evidencies/fase-1/lsblk.txt
    8  lsblk > evidencies/fase-1/lsblk.txt
    9  cd ..
   10  lsblk > evidencies/fase-1/lsblk.txt
   11  ip a > evidencies/fase-1/ip-a.txt
   12  hostnamectl
   13  hostnamectl > evidencies/fase-1/hostnamectl.txt
   14  mount
   15  mount > evidencies/fase-1/mount.txt
   16  ssh administrador@192.168.56.102 hostname > evidencies/fase-1/ssh-ok.txt
   17  history > evidencies/fase-1/history.txt

```