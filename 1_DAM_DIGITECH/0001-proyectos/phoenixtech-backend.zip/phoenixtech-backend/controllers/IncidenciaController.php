<?php

require_once __DIR__ . '/../models/Incidencia.php';

class IncidenciaController {

    public function index() {
        $model = new Incidencia();
        $incidencies = $model->getAll();
        require __DIR__ . '/../views/incidencies/list.php';
    }

    public function show($id) {
        $model = new Incidencia();
        $incidencia = $model->find($id);
        require __DIR__ . '/../views/incidencies/show.php';
    }

    public function create() {
        require __DIR__ . '/../views/incidencies/create.php';
    }

    public function store() {
        $model = new Incidencia();
        $model->create($_POST);
        header("Location: index.php");
        exit;
    }
}