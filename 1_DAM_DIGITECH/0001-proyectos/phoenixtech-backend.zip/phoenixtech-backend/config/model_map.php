<?php

return [
    'incidencia_table' => 'INCIDENCIES',
    'incidencia_id' => 'id_Incidencia',
    'incidencia_estat' => 'estat_Incidencia',
    'descripcio_Incidencia' => 'descripcio_Incidencia',
    'assumpte_Incidencia' => 'assumpte_Incidencia',
    'data_Apertura_Incidencia' => 'data_Apertura_Incidencia',

    'tecnic_table' => 'TECNICS',
    'tecnic_id' => 'id_Tecnic',
    'tecnic_nom' => 'nom_Tecnic',

    'client_table' => 'CLIENTS',
    'client_id' => 'id_Client',
    'client_nom' => 'nom_Client'
];