<h2>Detall Incidència</h2>

<p><strong>ID:</strong> <?= htmlspecialchars($incidencia['id_Incidencia']) ?></p>
<p><strong>Estat:</strong> <?= htmlspecialchars($incidencia['estat_Incidencia']) ?></p>
<p><strong>Descripció:</strong> <?= htmlspecialchars($incidencia['descripcio_Incidencia']) ?></p>

<a href="index.php">Tornar</a>