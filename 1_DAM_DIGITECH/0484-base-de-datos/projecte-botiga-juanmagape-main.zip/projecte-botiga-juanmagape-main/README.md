[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/pdyN2igW)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=23575873&assignment_repo_type=AssignmentRepo)
# Projecte Botiga DAM

## Objectiu

Aquest projecte simula el backend d’una botiga online utilitzant:

- MySQL (base de dades)
- PHP (visualització)
- Docker (entorn de treball)

---

## Requisits

- Tenir Docker instal·lat a la màquina virtual (MV)

---

## Execució del projecte

Dins de la MV que teniu amb ubuntu i amb Docker cal instal·lar i configrar **`git`** per poder clonar el vostre repositori.


1. Obrir un terminal a la MV

2. Instal·lar **`git`**

**`sudo apt update`**

**`sudo apt install git -y`**

3. Configurar **`Git`** (només una vegada)

**`git config --global user.name "El teu user nama de github"`**

**`git config --global user.email "el_teu_email@exemple.com"`**


4. Crear i anar a la carpeta de treball

```bash
cd ~
mkdir dam
cd dam
```

5. Clonar el repositori

Cal anar al vostre repositori del **`GitHub Classroom`** i copiar l’enllaç (botó verd Code → **`HTTPS`**)

Exemple:

git clone https://github.com/usuari/projecte-botiga.git

6. Entrar a la carpeta del projecte

```bash
cd projecte-botiga
```

7. Executar

```bash
docker compose up -d
```

La primera vegada pot tardar una mica.

---

## Accés a l’aplicació

Obre el navegador i ves a:

```
http://IP_DE_LA_TEVA_MV:8080
```

Si no saps la IP:

```bash
ip a
```

---

## Accés a MySQL

Per entrar a la base de dades:

```bash
docker exec -it mysql-db-1 mysql -u root -p
```

Password:

```
profe
```

---

## Què pots fer?

- Crear i modificar **Stored Procedures**
- Consultar dades
- Veure els canvis en temps real a la web
- Analitzar el codi dels procedures des del navegador

---

## Guardar canvis (Git)

```bash
git add .
git commit -m "Nom de l'exercici"
git push
```

---

## Exportar procedures i base de dades

Per poder entregar correctament els exercicis, cal exportar:

- els **procedures** (per a la correcció)
- la **base de dades completa** (per si cal revisar)

### Crear l’script d’exportació

Dins de la carpeta del projecte, crear un fitxer:

```bash
vi export.sh
```

Afegir el següent contingut:

```bash
#!/bin/bash

mkdir -p sql/export

echo "Exportant procedures..."

docker compose exec db mysqldump -u root -pprofe --routines --no-data --no-create-info botiga \
| grep -v '^/\*' \
| grep -v '^--' \
| grep -v '^$' \
> sql/export/procedures.sql

echo "Exportant base de dades completa..."

docker compose exec db mysqldump -u root -pprofe --routines botiga \
> sql/export/botiga_dump.sql

echo "Exportació completada:"
echo " - sql/export/procedures.sql"
echo " - sql/export/botiga_dump.sql"
```

---

### Donar permisos d’execució

```bash
chmod +x export.sh
```

---

### Executar l’exportació

```bash
./export.sh
```

---

### Guardar els fitxers al repositori

```bash
git add .
git commit -m "Export procedures i base de dades"
git push
```

---

### Resultat

Es generaran dos fitxers:

- `sql/export/procedures.sql` → fitxer principal de correcció
- `sql/export/botiga_dump.sql` → fitxer de suport

---

### Important

- El fitxer **procedures.sql** és el que s’utilitzarà principalment per corregir
- El fitxer **botiga_dump.sql** només s’utilitzarà si cal revisar el context complet
- Cal executar l’script cada vegada que es modifiquin els procedures

---

## Problemes típics

### No funciona la web
- Comprova que els contenidors estan actius:

```bash
sudo docker container ps
```

---

### No veus canvis
- Refresca el navegador

---

### Error amb MySQL
- Revisa el nom del contenidor:

```bash
sudo docker container ps
```

---

## Notes

Aquest entorn simula un sistema real:

- Base de dades (MySQL)
- Backend (PHP)
- Contenidors (Docker)

És una pràctica molt propera al món professional.
