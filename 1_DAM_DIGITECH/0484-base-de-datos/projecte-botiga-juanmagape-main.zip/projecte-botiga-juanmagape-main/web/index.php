<?php
$host = 'db';
$user = 'root';
$password = 'profe';
$database = 'botiga';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Error connexió: " . $conn->connect_error);
}

echo "
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f6f8;
    margin: 20px;
}

h1 {
    color: #2c3e50;
}

h2 {
    margin-top: 30px;
    color: #34495e;
}

table {
    border-collapse: collapse;
    width: 60%;
    background-color: white;
    margin-bottom: 20px;
}

th {
    background-color: #3498db;
    color: white;
    padding: 8px;
}

td {
    padding: 8px;
    text-align: center;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

button {
    padding: 10px 15px;
    background-color: #2ecc71;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    font-size: 20px;
}

button:hover {
    background-color: #27ae60;
}
</style>
";

echo "<div style='max-width: 1000px; margin: auto;'>";



echo "<div style=\"margin-bottom: 20px;\">
    <button onclick='location.reload()' >Refrescar dades</button>
    <a href='procedures.php'><button>Veure Procedures</button></a>
</div>" ;

echo "<h1>Backend Botiga (Estat en temps real)</h1>";

echo "<hr>";

echo "<h2>Clients</h2>";

$result = $conn->query("SELECT * FROM clients");

echo "<table border='1'>";
echo "<tr>
        <th>Codi</th>
        <th>Nom</th>
        <th>Correu</th>
      </tr>";
while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id_cli']}</td>
        <td>{$row['nom_cli']}</td>
        <td>{$row['email_cli']}</td>
    </tr>";
}
echo "</table>";

echo "<hr>";

echo "<h2>Productes</h2>";
$result = $conn->query("SELECT * FROM productes");

echo "<table border='1'>";

echo "<tr>
        <th>Codi</th>
        <th>Nom</th>
        <th>Preu</th>
        <th>Stock</th>
      </tr>";

while($row = $result->fetch_assoc()) {
    if ($row['stock_prod'] <= 5) {
        echo "<tr style='background-color: #ffcccc'>";
    } else {
        echo "<tr>";
    };

    echo "<td>{$row['id_prod']}</td>
        <td>{$row['nom_prod']}</td>
        <td>{$row['preu_prod']}</td>
        <td>{$row['stock_prod']}</td>
    </tr>";
}

echo "</table>";

echo "<hr>";

echo "<h2>Comandes</h2>";
$result = $conn->query("SELECT * FROM comandes");
echo "<table border='1'>";
echo "<tr>
        <th>CodiCda</th>
        <th>CodiCli</th>
        <th>Data</th>
      </tr>";
while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id_cda']}</td>
        <td>{$row['id_cli']}</td>
        <td>{$row['data']}</td>
    </tr>";
}
echo "</table>";

echo "<hr>";

echo "<h2>Detalls Comanda</h2>";
$result = $conn->query("SELECT * FROM detalls_comanda");
echo "<table border='1'>";
echo "<tr>
        <th>CodiDetCda</th>
        <th>CodiCda</th>
        <th>CodiProd</th>
        <th>QtatVenuda</th>
      </tr>";
while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['id_comanda']}</td>
        <td>{$row['id_producte']}</td>
        <td>{$row['qtat_venuda']}</td>
    </tr>";
}
echo "</table>";



echo "</div>";




$conn->close();
?>
