<?php
$host = 'db';
$user = 'root';
$password = 'profe';
$database = 'botiga';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Error connexió: " . $conn->connect_error);
}

echo '
<link href="https://cdn.jsdelivr.net/npm/prismjs/themes/prism.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/prismjs/prism.js"></script>
<script src="https://cdn.jsdelivr.net/npm/prismjs/components/prism-sql.min.js"></script>

';

echo "<style>
body { font-family: Arial; margin: 20px; background:#f4f6f8; }
h1, h2 { color:#2c3e50; }
pre {
    padding: 10px;
    overflow: auto;
}
button {
    padding: 10px 15px;
    background-color: #2ecc71;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    font-size: 20px;
}
</style>";

echo "<h1>Procedures disponibles</h1>";

echo "<a href='index.php'><button>⬅ Tornar</button></a><br><br>";

// Llistar procedures
$result = $conn->query("
SELECT ROUTINE_NAME
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_TYPE = 'PROCEDURE'
AND ROUTINE_SCHEMA = 'botiga'
");

echo "<ul>";
while($row = $result->fetch_assoc()) {
    $name = $row['ROUTINE_NAME'];
    echo "<li><a href='procedures.php?proc=$name'>$name</a></li>";
}
echo "</ul>";

// Mostrar codi si s'ha seleccionat
if (isset($_GET['proc'])) {
    $proc = $_GET['proc'];

    $result = $conn->query("SHOW CREATE PROCEDURE $proc");
    $row = $result->fetch_assoc();

    echo "<h2>Codi de $proc</h2>";
    $code = htmlspecialchars($row['Create Procedure']);
    echo "<pre><code class='language-sql'>$code</code></pre>";


}

$conn->close();
?>