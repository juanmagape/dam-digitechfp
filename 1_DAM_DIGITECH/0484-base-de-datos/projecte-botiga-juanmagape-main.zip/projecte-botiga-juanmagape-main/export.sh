#!/bin/bash

set -eo pipefail

readonly RUTA="sql/export/"

mkdir -p "$RUTA"

readonly DATABASES=(
    "botiga"
    "hotel_reserves"
)

DATA=$(date +%d/%m/%Y)
HORA=$(date +%H:%M:%S)
DATA_I_HORA="$DATA a les $HORA"

echo "Inici exportació: $DATA_I_HORA"
echo ""

for DB in "${DATABASES[@]}"; do

    FITXER_RUTINES="$RUTA${DB}_routines.sql"
    FITXER_BACKUP="$RUTA${DB}_dump.sql"

    echo "-- Data del dump -> $DATA_I_HORA" > "$FITXER_RUTINES"
    echo >>  "$FITXER_RUTINES"

    echo "Exportant procedures i functions de la base de dades $DB..."

    (
    docker compose exec -T db mysqldump \
        -u root \
        -pprofe \
        --routines \
        --skip-triggers \
        --no-data \
        --no-create-info \
        "$DB" \
        | grep -v '^/\*' \
        | grep -v '^--' \
        | grep -v '^$'
    ) >> "$FITXER_RUTINES" || true

    echo "Exportant dump complet de la base de dades $DB..."
    
    echo "-- Data del dump -> $DATA_I_HORA" > "$FITXER_BACKUP"
    echo >> "$FITXER_BACKUP"
    docker compose exec -T db mysqldump \
    -u root \
    -pprofe \
    --routines \
    "$DB" \
    >> "$FITXER_BACKUP"

    echo "========================================"
    echo "Exportació de $DB completada."
    echo "========================================"
    echo ""

done

echo "Exportació global completada:"
echo ""

for DB in "${DATABASES[@]}"; do
    echo " - El fitxer $RUTA${DB}_routines.sql  -> conté els procedures + functions de la DB ${DB}"
    echo " - El fitxer $RUTA${DB}_dump.sql      -> conté el dump complet de la DB ${DB}"

done