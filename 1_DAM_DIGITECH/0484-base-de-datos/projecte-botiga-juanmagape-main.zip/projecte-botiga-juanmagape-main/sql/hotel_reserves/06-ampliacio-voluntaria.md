# Ampliació voluntaria

## OPCIÓ A

### TASCA A1

#### Explicació: En la tasca A1 se crea una función que calcula y devuelve el total de dinero pagado por una reserva específica. Para ello, realiza un SELECT SUM buscando el ID de la reserva en la tabla de pagos.

### Codi SQL

```
DELIMITER //

CREATE FUNCTION fn_total_pagat(p_id_reserva DECIMAL(10,2))
RETURNS DECIMAL(10,2) 
DETERMINISTIC
BEGIN

    DECLARE v_import_total DECIMAL(10,2); 

    SELECT SUM(import_paga) INTO v_import_total 
    FROM PAGAMENTS
    WHERE id_reserva = p_id_reserva;

    RETURN v_import_total;

END //

DELIMITER ;
```

### Execució real

```
mysql> DELIMITER //
mysql>
mysql> CREATE FUNCTION fn_total_pagat(p_id_reserva DECIMAL(10,2))
    -> RETURNS DECIMAL(10,2)
    -> DETERMINISTIC
    -> BEGIN
    ->
    ->     DECLARE v_import_total DECIMAL(10,2);
    ->
    ->     SELECT SUM(import_paga) INTO v_import_total
    ->     FROM PAGAMENTS
    ->     WHERE id_reserva = p_id_reserva;
    ->
    ->     RETURN v_import_total;
    ->
    -> END //
Query OK, 0 rows affected (0.04 sec)

mysql>
mysql> DELIMITER ;

```

#### Sortida real de MysQL

```
mysql> SELECT fn_total_pagat(1);
+-------------------+
| fn_total_pagat(1) |
+-------------------+
|            216.90 |
+-------------------+
1 row in set (0.01 sec)

mysql>

```


### TASCA A2

#### Explicació: En la tasca A2 se crea una función que calcula el importe pendiente de una reserva, controlando que los valores nulos sean cero. Lo hace restando el dinero ya pagado al precio total guardado en la tabla de reservas.

### Codi SQL

```
DELIMITER //

CREATE FUNCTION fn_import_pendent(p_id_reserva DECIMAL(10,2))
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN

DECLARE import_total DECIMAL(10,2);
DECLARE import_pagat DECIMAL(10,2);

SELECT imp_tot_reserva INTO import_total
FROM RESERVES 
WHERE id_reserva = p_id_reserva;

SELECT SUM(import_paga) INTO import_pagat 
FROM PAGAMENTS 
WHERE id_reserva = p_id_reserva; 

IF import_pagat IS NULL THEN
        SET import_pagat = 0.00;
    END IF;

    RETURN import_total - import_pagat;

END //

DELIMITER ;
```

### Execució real

```
mysql> DELIMITER //
mysql>
mysql> CREATE FUNCTION fn_import_pendent(p_id_reserva DECIMAL(10,2))
    -> RETURNS DECIMAL(10,2)
    -> DETERMINISTIC
    -> BEGIN
    ->
    -> DECLARE import_total DECIMAL(10,2);
    -> DECLARE import_pagat DECIMAL(10,2);
    ->
    -> SELECT imp_tot_reserva INTO import_total
    -> FROM RESERVES
    -> WHERE id_reserva = p_id_reserva;
    ->
    -> SELECT SUM(import_paga) INTO import_pagat
    -> FROM PAGAMENTS
    -> WHERE id_reserva = p_id_reserva;
    ->
    -> IF import_pagat IS NULL THEN
    ->         SET import_pagat = 0.00;
    ->     END IF;
    ->
    ->     RETURN import_total - import_pagat;
    ->
    -> END //
Query OK, 0 rows affected (0.04 sec)

mysql>
mysql> DELIMITER ;
mysql>

```

#### Sortida real de MysQL

```
mysql> select fn_import_pendent(1);
+----------------------+
| fn_import_pendent(1) |
+----------------------+
|                90.00 |
+----------------------+
1 row in set (0.00 sec)

mysql>

```

### TASCA A3

#### Explicació: En la tasca A3 se realiza un SELECT a la tabla de reservas que muestra el estado financiero de cada cliente de forma rápida. Llama directamente a las dos funciones creades para mostrar el total pagado y el pendiente.

### Codi SQL

```
SELECT
    id_reserva,
    fn_total_pagat(id_reserva),
    fn_import_pendent(id_reserva)
FROM RESERVES;

```

### Execució real

```
mysql> SELECT
    ->     id_reserva,
    ->     fn_total_pagat(id_reserva),
    ->     fn_import_pendent(id_reserva)
    -> FROM RESERVES;

```

#### Sortida real de MysQL

```
+------------+----------------------------+-------------------------------+
| id_reserva | fn_total_pagat(id_reserva) | fn_import_pendent(id_reserva) |
+------------+----------------------------+-------------------------------+
|          1 |                     216.90 |                         90.00 |
|          2 |                     763.13 |                          0.00 |
|          3 |                     500.00 |                        417.13 |
|          4 |                     143.00 |                          0.00 |
+------------+----------------------------+-------------------------------+
4 rows in set (0.02 sec)

mysql>


```

# REFLEXIÓ FINAL

Se han implementado funciones para automatizar cálculos de pagos directamente en la base de datos, superando la dificultad de gestionar errores con valores nulos (NULL). Como mejora futura, estas funciones podrían reutilizarse llamándose entre sí o integrándose dentro de vistas para simplificar el código.