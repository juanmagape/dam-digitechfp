CREATE DATABASE IF NOT EXISTS botiga;
USE botiga;

CREATE TABLE clients (
    id_cli INT AUTO_INCREMENT PRIMARY KEY,
    nom_cli VARCHAR(50),
    email_cli VARCHAR(100)
);

CREATE TABLE productes (
    id_prod INT AUTO_INCREMENT PRIMARY KEY,
    nom_prod VARCHAR(50),
    preu_prod DECIMAL(10,2),
    stock_prod INT
);

CREATE TABLE comandes (
    id_cda INT AUTO_INCREMENT PRIMARY KEY,
    id_cli INT,
    data DATETIME
);

CREATE TABLE detalls_comanda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_comanda INT,
    id_producte INT,
    qtat_venuda INT
);