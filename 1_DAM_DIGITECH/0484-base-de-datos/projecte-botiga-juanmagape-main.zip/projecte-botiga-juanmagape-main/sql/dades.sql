USE botiga;

INSERT INTO clients (nom_cli, email_cli) VALUES
('Anna', 'anna@email.com'),
('Joan', 'joan@email.com'),
('Maria', 'maria@email.com');

INSERT INTO productes (nom_prod, preu_prod, stock_prod) VALUES
('Teclat', 20.50, 10),
('Ratol', 10.00, 25),
('Monitor', 150.00, 5);