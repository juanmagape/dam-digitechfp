-- Data del dump -> 03/06/2026 a les 12:02:08

-- MySQL dump 10.13  Distrib 8.4.8, for Linux (x86_64)
--
-- Host: localhost    Database: hotel_reserves
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `id_client` int NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cognoms_client` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_client` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel_client` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dni_client` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_alta` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `obser_client` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `email_client` (`email_client`),
  UNIQUE KEY `dni_client` (`dni_client`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
INSERT INTO `CLIENTS` VALUES (1,'Joan','Serra Puig','joan.serra@gmail.com','600111222','72870739T','2026-04-29 09:55:54','Client habitual'),(2,'Marta','Casals Riera','marta.casals@gmail.com','600333444','72185939W','2026-04-29 09:55:54',NULL),(3,'Pau','Vidal Costa','pau.vidal@gmail.com','600555666','20719618E','2026-04-29 09:55:54','Viatja amb menors'),(4,'Laia','Roca Torres','laia.roca@gmail.com','600777888','34316289J','2026-04-29 09:55:54',NULL),(5,'Nil','Ferrer Soler','nil.ferrer@gmail.com','600999000','69256903Q','2026-04-29 09:55:54',NULL);
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HABITACIONS`
--

DROP TABLE IF EXISTS `HABITACIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HABITACIONS` (
  `id_habitacio` int NOT NULL AUTO_INCREMENT,
  `num_habitacio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `planta_habitacio` int NOT NULL,
  `id_tipus_hab` int NOT NULL,
  `estat_habitacio` enum('disponible','ocupada','manteniment','fora_servei') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disponible',
  `obser_hab` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_habitacio`),
  UNIQUE KEY `num_habitacio` (`num_habitacio`),
  KEY `id_tipus_hab` (`id_tipus_hab`),
  CONSTRAINT `HABITACIONS_ibfk_1` FOREIGN KEY (`id_tipus_hab`) REFERENCES `TIPUS_HABITACIONS` (`id_tipus_hab`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HABITACIONS`
--

LOCK TABLES `HABITACIONS` WRITE;
/*!40000 ALTER TABLE `HABITACIONS` DISABLE KEYS */;
INSERT INTO `HABITACIONS` VALUES (1,'101',1,1,'disponible',NULL),(2,'102',1,2,'disponible',NULL),(3,'103',1,2,'manteniment','RevisiÃ³ aire condicionat'),(4,'201',2,3,'disponible',NULL),(5,'202',2,4,'disponible',NULL),(6,'301',3,5,'disponible','Vistes al mar');
/*!40000 ALTER TABLE `HABITACIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG_ESTATS_RESERVA`
--

DROP TABLE IF EXISTS `LOG_ESTATS_RESERVA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG_ESTATS_RESERVA` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_reserva` int DEFAULT NULL,
  `estat_anterior` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estat_nou` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_canvi` datetime DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG_ESTATS_RESERVA`
--

LOCK TABLES `LOG_ESTATS_RESERVA` WRITE;
/*!40000 ALTER TABLE `LOG_ESTATS_RESERVA` DISABLE KEYS */;
INSERT INTO `LOG_ESTATS_RESERVA` VALUES (1,1,'pendent','checkout','2026-05-19 11:09:10'),(2,4,'confirmada','checkin','2026-05-28 08:31:12'),(3,2,'confirmada','checkout','2026-05-28 08:55:17');
/*!40000 ALTER TABLE `LOG_ESTATS_RESERVA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG_MODIFICACIONS_PAGAMENTS`
--

DROP TABLE IF EXISTS `LOG_MODIFICACIONS_PAGAMENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG_MODIFICACIONS_PAGAMENTS` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_paga` int DEFAULT NULL,
  `import_antic` decimal(10,2) DEFAULT NULL,
  `import_nou` decimal(10,2) DEFAULT NULL,
  `data_modificacio` datetime DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG_MODIFICACIONS_PAGAMENTS`
--

LOCK TABLES `LOG_MODIFICACIONS_PAGAMENTS` WRITE;
/*!40000 ALTER TABLE `LOG_MODIFICACIONS_PAGAMENTS` DISABLE KEYS */;
INSERT INTO `LOG_MODIFICACIONS_PAGAMENTS` VALUES (1,1,100.00,10.00,'2026-05-19 11:21:36'),(2,4,143.00,43.00,'2026-05-21 08:10:47');
/*!40000 ALTER TABLE `LOG_MODIFICACIONS_PAGAMENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PAGAMENTS`
--

DROP TABLE IF EXISTS `PAGAMENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PAGAMENTS` (
  `id_paga` int NOT NULL AUTO_INCREMENT,
  `id_reserva` int NOT NULL,
  `data_paga` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `import_paga` decimal(10,2) NOT NULL,
  `metode_paga` enum('targeta','efectiu','transferencia','bizum') COLLATE utf8mb4_unicode_ci NOT NULL,
  `concepte_paga` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pagament reserva',
  PRIMARY KEY (`id_paga`),
  KEY `id_reserva` (`id_reserva`),
  CONSTRAINT `PAGAMENTS_ibfk_1` FOREIGN KEY (`id_reserva`) REFERENCES `RESERVES` (`id_reserva`) ON DELETE CASCADE,
  CONSTRAINT `PAGAMENTS_chk_1` CHECK ((`import_paga` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PAGAMENTS`
--

LOCK TABLES `PAGAMENTS` WRITE;
/*!40000 ALTER TABLE `PAGAMENTS` DISABLE KEYS */;
INSERT INTO `PAGAMENTS` VALUES (1,1,'2026-04-29 09:55:54',10.00,'targeta','Paga i senyal'),(3,3,'2026-04-29 09:55:54',300.00,'transferencia','Reserva confirmada'),(4,4,'2026-04-29 09:55:54',43.00,'efectiu','Pagament complet'),(6,2,'2026-05-07 07:52:47',100.00,'bizum','Pagament parcial'),(8,4,'2026-05-13 10:10:08',100.00,'bizum','Pagament reserva'),(10,3,'2026-05-13 10:31:11',200.00,'bizum','Pagament reserva'),(11,1,'2026-04-29 09:55:54',206.90,'targeta','Pagament final'),(12,2,'2026-05-28 08:42:27',100.00,'bizum','Pagament parcial'),(13,2,'2026-05-28 08:43:29',100.00,'bizum','Pagament parcial'),(14,2,'2026-05-28 08:44:30',100.00,'bizum','Pagament parcial'),(15,2,'2026-05-28 08:54:48',363.13,'targeta','Pagament final per checkout');
/*!40000 ALTER TABLE `PAGAMENTS` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_impedeix_sobrepagament` BEFORE INSERT ON `PAGAMENTS` FOR EACH ROW BEGIN
    DECLARE v_pendent DECIMAL(10,2);

    SELECT imp_tot_reserva - IFNULL((SELECT SUM(import_paga) FROM PAGAMENTS WHERE id_reserva = NEW.id_reserva), 0)
    INTO v_pendent
    FROM RESERVES
    WHERE id_reserva = NEW.id_reserva;

    IF NEW.import_paga > v_pendent THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: L''import del pagament supera el deute pendent.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_log_modificacions_sospitoses` AFTER UPDATE ON `PAGAMENTS` FOR EACH ROW BEGIN
    IF OLD.import_paga != NEW.import_paga THEN

        INSERT INTO LOG_MODIFICACIONS_PAGAMENTS (
            id_paga,
            import_antic,
            import_nou,
            data_modificacio
        ) VALUES (
            NEW.id_paga,
            OLD.import_paga,
            NEW.import_paga,
            NOW()
        );

    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `RESERVA_SERVEIS`
--

DROP TABLE IF EXISTS `RESERVA_SERVEIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESERVA_SERVEIS` (
  `id_reserva_servei` int NOT NULL AUTO_INCREMENT,
  `id_reserva` int NOT NULL,
  `id_servei` int NOT NULL,
  `quantitat` int NOT NULL DEFAULT '1',
  `preu_unitari_aplicat` decimal(10,2) NOT NULL,
  `subtotal_servei` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_reserva_servei`),
  KEY `id_reserva` (`id_reserva`),
  KEY `id_servei` (`id_servei`),
  CONSTRAINT `RESERVA_SERVEIS_ibfk_1` FOREIGN KEY (`id_reserva`) REFERENCES `RESERVES` (`id_reserva`) ON DELETE CASCADE,
  CONSTRAINT `RESERVA_SERVEIS_ibfk_2` FOREIGN KEY (`id_servei`) REFERENCES `SERVEIS` (`id_servei`),
  CONSTRAINT `RESERVA_SERVEIS_chk_1` CHECK ((`quantitat` > 0)),
  CONSTRAINT `RESERVA_SERVEIS_chk_2` CHECK ((`preu_unitari_aplicat` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESERVA_SERVEIS`
--

LOCK TABLES `RESERVA_SERVEIS` WRITE;
/*!40000 ALTER TABLE `RESERVA_SERVEIS` DISABLE KEYS */;
INSERT INTO `RESERVA_SERVEIS` VALUES (1,1,1,2,12.00,24.00),(2,2,2,5,15.00,75.00),(3,3,4,2,25.00,50.00),(4,4,5,1,20.00,20.00);
/*!40000 ALTER TABLE `RESERVA_SERVEIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESERVES`
--

DROP TABLE IF EXISTS `RESERVES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESERVES` (
  `id_reserva` int NOT NULL AUTO_INCREMENT,
  `id_client` int NOT NULL,
  `id_habitacio` int NOT NULL,
  `data_entra_reserva` date NOT NULL,
  `data_surt_reserva` date NOT NULL,
  `adults_reserva` int NOT NULL DEFAULT '1',
  `menors_reserva` int NOT NULL DEFAULT '0',
  `en_estat_reserva` enum('pendent','confirmada','checkin','checkout','cancel_lada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendent',
  `preu_nit_reserva` decimal(10,2) DEFAULT NULL,
  `quantitat_nits_reserva` int DEFAULT NULL,
  `subtotal_estada_reserva` decimal(10,2) DEFAULT NULL,
  `per_dte_reserva` int NOT NULL DEFAULT '0',
  `imp_dte_reserva` decimal(10,2) DEFAULT NULL,
  `imp_servei_reserva` decimal(10,2) NOT NULL DEFAULT '0.00',
  `per_iva_reserva` int NOT NULL DEFAULT '10',
  `imp_iva_reserva` decimal(10,2) DEFAULT NULL,
  `imp_tot_reserva` decimal(10,2) DEFAULT NULL,
  `data_crea_reserva` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `obser_reserva` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_reserva`),
  KEY `id_client` (`id_client`),
  KEY `id_habitacio` (`id_habitacio`),
  CONSTRAINT `RESERVES_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `CLIENTS` (`id_client`),
  CONSTRAINT `RESERVES_ibfk_2` FOREIGN KEY (`id_habitacio`) REFERENCES `HABITACIONS` (`id_habitacio`),
  CONSTRAINT `RESERVES_chk_1` CHECK ((`data_surt_reserva` > `data_entra_reserva`)),
  CONSTRAINT `RESERVES_chk_2` CHECK ((`adults_reserva` > 0)),
  CONSTRAINT `RESERVES_chk_3` CHECK ((`menors_reserva` >= 0)),
  CONSTRAINT `RESERVES_chk_4` CHECK (((`per_dte_reserva` >= 0) and (`per_dte_reserva` <= 100))),
  CONSTRAINT `RESERVES_chk_5` CHECK (((`per_iva_reserva` >= 0) and (`per_iva_reserva` <= 100)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESERVES`
--

LOCK TABLES `RESERVES` WRITE;
/*!40000 ALTER TABLE `RESERVES` DISABLE KEYS */;
INSERT INTO `RESERVES` VALUES (1,1,2,'2026-05-10','2026-05-13',2,0,'checkout',85.00,3,255.00,0,0.00,24.00,10,27.90,306.90,'2026-04-29 09:55:54','Cap de setmana llarg'),(2,2,4,'2026-07-02','2026-07-07',2,1,'checkout',137.50,5,687.50,10,68.75,75.00,10,69.38,763.13,'2026-04-29 09:55:54','Reserva dâ€™estiu'),(3,3,6,'2026-08-15','2026-08-18',2,0,'confirmada',275.00,3,825.00,5,41.25,50.00,10,83.38,917.13,'2026-04-29 09:55:54','Aniversari'),(4,4,1,'2026-04-28','2026-04-30',1,0,'checkin',55.00,2,110.00,0,0.00,20.00,10,13.00,143.00,'2026-04-29 09:55:54',NULL);
/*!40000 ALTER TABLE `RESERVES` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_impedir_overbooking` BEFORE INSERT ON `RESERVES` FOR EACH ROW BEGIN
    IF EXISTS (
        SELECT 1
        FROM RESERVES
        WHERE id_habitacio = NEW.id_habitacio
          AND en_estat_reserva NOT IN ('cancel_lada', 'checkout')
          AND NEW.data_entra_reserva < data_surt_reserva
          AND NEW.data_surt_reserva > data_entra_reserva
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: Habitacio ocupada en aquestes dates';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_bloqueja_checkout_impagat` BEFORE UPDATE ON `RESERVES` FOR EACH ROW BEGIN
    DECLARE v_total_pagat DECIMAL(10,2);

    IF NEW.en_estat_reserva = 'checkout' THEN

        SELECT SUM(import_paga) INTO v_total_pagat
        FROM PAGAMENTS
        WHERE id_reserva = NEW.id_reserva;

        IF v_total_pagat IS NULL THEN
            SET v_total_pagat = 0;
        END IF;

        IF v_total_pagat < NEW.imp_tot_reserva THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Error: No es pot fer checkout. Hi ha imports pendents de pagament.';
        END IF;

    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_log_canvi_estat_reserva` AFTER UPDATE ON `RESERVES` FOR EACH ROW BEGIN
    IF OLD.en_estat_reserva != NEW.en_estat_reserva THEN
        INSERT INTO LOG_ESTATS_RESERVA (id_reserva, estat_anterior, estat_nou, data_canvi) 
        VALUES (NEW.id_reserva, OLD.en_estat_reserva, NEW.en_estat_reserva, NOW());
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `SERVEIS`
--

DROP TABLE IF EXISTS `SERVEIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SERVEIS` (
  `id_servei` int NOT NULL AUTO_INCREMENT,
  `nom_servei` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pr_unit_servei` decimal(10,2) NOT NULL,
  `en_tipus_cobrament` enum('per_estada','per_nit','per_persona') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'per_estada',
  `esta_actiu` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_servei`),
  UNIQUE KEY `nom_servei` (`nom_servei`),
  CONSTRAINT `SERVEIS_chk_1` CHECK ((`pr_unit_servei` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SERVEIS`
--

LOCK TABLES `SERVEIS` WRITE;
/*!40000 ALTER TABLE `SERVEIS` DISABLE KEYS */;
INSERT INTO `SERVEIS` VALUES (1,'Esmorzar',12.00,'per_persona',1),(2,'Parking',15.00,'per_nit',1),(3,'Bressol',8.00,'per_nit',1),(4,'Spa',25.00,'per_persona',1),(5,'Late checkout',20.00,'per_estada',1);
/*!40000 ALTER TABLE `SERVEIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TEMPORADES`
--

DROP TABLE IF EXISTS `TEMPORADES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TEMPORADES` (
  `id_temporada` int NOT NULL AUTO_INCREMENT,
  `nom_temporada` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inici` date NOT NULL,
  `data_fi` date NOT NULL,
  `factor_preu` decimal(4,2) NOT NULL DEFAULT '1.00',
  PRIMARY KEY (`id_temporada`),
  UNIQUE KEY `nom_temporada` (`nom_temporada`),
  CONSTRAINT `TEMPORADES_chk_1` CHECK ((`data_fi` >= `data_inici`)),
  CONSTRAINT `TEMPORADES_chk_2` CHECK ((`factor_preu` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TEMPORADES`
--

LOCK TABLES `TEMPORADES` WRITE;
/*!40000 ALTER TABLE `TEMPORADES` DISABLE KEYS */;
INSERT INTO `TEMPORADES` VALUES (1,'Baixa 2026 hivern','2026-01-08','2026-03-31',0.90),(2,'Mitjana 2026 primavera','2026-04-01','2026-06-20',1.00),(3,'Alta 2026 estiu','2026-06-21','2026-09-10',1.25),(4,'Mitjana 2026 tardor','2026-09-11','2026-11-30',1.00),(5,'Alta 2026 ponts i festes','2026-12-01','2026-12-31',1.20);
/*!40000 ALTER TABLE `TEMPORADES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TIPUS_HABITACIONS`
--

DROP TABLE IF EXISTS `TIPUS_HABITACIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TIPUS_HABITACIONS` (
  `id_tipus_hab` int NOT NULL AUTO_INCREMENT,
  `nom_tipus_hab` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacitat_hab` int NOT NULL,
  `preu_base_nit_hab` decimal(10,2) NOT NULL,
  `te_bany_privat` tinyint(1) NOT NULL DEFAULT '1',
  `te_balco` tinyint(1) NOT NULL DEFAULT '0',
  `te_vistes_mar` tinyint(1) NOT NULL DEFAULT '0',
  `desc_tipus_hab` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_tipus_hab`),
  UNIQUE KEY `nom_tipus_hab` (`nom_tipus_hab`),
  CONSTRAINT `TIPUS_HABITACIONS_chk_1` CHECK ((`capacitat_hab` > 0)),
  CONSTRAINT `TIPUS_HABITACIONS_chk_2` CHECK ((`preu_base_nit_hab` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TIPUS_HABITACIONS`
--

LOCK TABLES `TIPUS_HABITACIONS` WRITE;
/*!40000 ALTER TABLE `TIPUS_HABITACIONS` DISABLE KEYS */;
INSERT INTO `TIPUS_HABITACIONS` VALUES (1,'Individual',1,55.00,1,0,0,'HabitaciÃ³ individual estÃ ndard'),(2,'Doble',2,85.00,1,0,0,'HabitaciÃ³ doble estÃ ndard'),(3,'Doble superior',2,110.00,1,1,0,'HabitaciÃ³ doble superior amb balcÃ³'),(4,'Familiar',4,150.00,1,1,0,'HabitaciÃ³ familiar per a 4 persones'),(5,'Suite',4,220.00,1,1,1,'Suite amb vistes al mar');
/*!40000 ALTER TABLE `TIPUS_HABITACIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pagaments`
--

DROP TABLE IF EXISTS `log_pagaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_pagaments` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_reserva` int DEFAULT NULL,
  `import_pagament` decimal(10,2) DEFAULT NULL,
  `data_log` datetime DEFAULT CURRENT_TIMESTAMP,
  `missatge` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pagaments`
--

LOCK TABLES `log_pagaments` WRITE;
/*!40000 ALTER TABLE `log_pagaments` DISABLE KEYS */;
INSERT INTO `log_pagaments` VALUES (1,1,100.00,'2026-05-13 10:01:38','Nou pagament registrat de 100.00 euros'),(2,4,100.00,'2026-05-13 10:10:08','Nou pagament registrat de 100.00 euros'),(3,1,100.00,'2026-05-13 10:16:32','Nou pagament registrat de 100.00 euros'),(4,3,200.00,'2026-05-13 10:31:11','Nou pagament registrat de 200.00 euros');
/*!40000 ALTER TABLE `log_pagaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_pagaments_reserva`
--

DROP TABLE IF EXISTS `v_pagaments_reserva`;
/*!50001 DROP VIEW IF EXISTS `v_pagaments_reserva`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_pagaments_reserva` AS SELECT 
 1 AS `id_reserva`,
 1 AS `Client`,
 1 AS `imp_tot_reserva`,
 1 AS `Total pagat`,
 1 AS `Pendent Pagament`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_reserves_pendents`
--

DROP TABLE IF EXISTS `v_reserves_pendents`;
/*!50001 DROP VIEW IF EXISTS `v_reserves_pendents`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_reserves_pendents` AS SELECT 
 1 AS `Client`,
 1 AS `Habitacio`,
 1 AS `Estat`,
 1 AS `Import pendent`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_resum_clients`
--

DROP TABLE IF EXISTS `v_resum_clients`;
/*!50001 DROP VIEW IF EXISTS `v_resum_clients`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_resum_clients` AS SELECT 
 1 AS `Client`,
 1 AS `Nombre reserves`,
 1 AS `Total pagat`,
 1 AS `Import pendent acumulat`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_resum_reserves`
--

DROP TABLE IF EXISTS `v_resum_reserves`;
/*!50001 DROP VIEW IF EXISTS `v_resum_reserves`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_resum_reserves` AS SELECT 
 1 AS `id_reserva`,
 1 AS `Client`,
 1 AS `HabitaciÃ³`,
 1 AS `Tipus`,
 1 AS `Data entr.`,
 1 AS `Data surt.`,
 1 AS `# nits`,
 1 AS `Estat reserva`,
 1 AS `Import total`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'hotel_reserves'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_import_pendent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_import_pendent`(p_id_reserva DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN

DECLARE import_total DECIMAL(10,2);
DECLARE import_pagat DECIMAL(10,2);

SELECT imp_tot_reserva INTO import_total
FROM RESERVES 
WHERE id_reserva = p_id_reserva;

SELECT SUM(import_paga) INTO import_pagat 
FROM PAGAMENTS 
WHERE id_reserva = p_id_reserva; 

IF import_pagat IS NULL THEN
        SET import_pagat = 0.00;
    END IF;

    RETURN import_total - import_pagat;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_total_pagat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_total_pagat`(p_id_reserva INT) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN

    DECLARE v_import_total DECIMAL(10,2); 

    SELECT SUM(import_paga) INTO v_import_total 
    FROM PAGAMENTS
    WHERE id_reserva = p_id_reserva;

    RETURN v_import_total;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_afegir_pagament` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_afegir_pagament`(
    IN p_id_reserva INT, 
    IN p_import DECIMAL(10,2), 
    IN p_metode VARCHAR(50), 
    IN p_descripcio VARCHAR(255)
)
BEGIN
    IF p_import <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: L''import ha de ser superior a 0.';
    END IF;

    INSERT INTO PAGAMENTS (id_reserva, import_paga, metode_paga, concepte_paga) 
    VALUES (p_id_reserva, p_import, p_metode, p_descripcio);

    UPDATE RESERVES 
    SET en_estat_reserva = 'confirmada' 
    WHERE id_reserva = p_id_reserva 
      AND en_estat_reserva = 'pendent'
      AND imp_tot_reserva <= (
          SELECT SUM(import_paga) FROM PAGAMENTS WHERE id_reserva = p_id_reserva
      );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_checkout_reserva` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_checkout_reserva`(IN p_id_reserva INT)
BEGIN
    IF (SELECT imp_tot_reserva FROM RESERVES WHERE id_reserva = p_id_reserva) > 
       IFNULL((SELECT SUM(import_paga) FROM PAGAMENTS WHERE id_reserva = p_id_reserva), 0) THEN
       
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Hi ha pagaments pendents. No es pot fer el checkout.';
    END IF;

    UPDATE RESERVES SET en_estat_reserva = 'checkout' WHERE id_reserva = p_id_reserva;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_pagaments_reserva`
--

/*!50001 DROP VIEW IF EXISTS `v_pagaments_reserva`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_pagaments_reserva` AS select `res`.`id_reserva` AS `id_reserva`,concat(`cli`.`nom_client`,' ',`cli`.`cognoms_client`) AS `Client`,`res`.`imp_tot_reserva` AS `imp_tot_reserva`,coalesce(sum(`paga`.`import_paga`),0) AS `Total pagat`,(`res`.`imp_tot_reserva` - coalesce(sum(`paga`.`import_paga`),0)) AS `Pendent Pagament` from ((`RESERVES` `res` join `CLIENTS` `cli` on((`res`.`id_client` = `cli`.`id_client`))) left join `PAGAMENTS` `paga` on((`res`.`id_reserva` = `paga`.`id_reserva`))) group by `res`.`id_reserva`,`cli`.`nom_client`,`cli`.`cognoms_client`,`res`.`imp_tot_reserva` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_reserves_pendents`
--

/*!50001 DROP VIEW IF EXISTS `v_reserves_pendents`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_reserves_pendents` AS select concat(`cli`.`nom_client`,' ',`cli`.`cognoms_client`) AS `Client`,`hab`.`num_habitacio` AS `Habitacio`,`res`.`en_estat_reserva` AS `Estat`,(`res`.`imp_tot_reserva` - ifnull(sum(`pag`.`import_paga`),0)) AS `Import pendent` from (((`RESERVES` `res` join `CLIENTS` `cli` on((`res`.`id_client` = `cli`.`id_client`))) join `HABITACIONS` `hab` on((`res`.`id_habitacio` = `hab`.`id_habitacio`))) left join `PAGAMENTS` `pag` on((`res`.`id_reserva` = `pag`.`id_reserva`))) group by `res`.`id_reserva`,`cli`.`nom_client`,`cli`.`cognoms_client`,`hab`.`num_habitacio`,`res`.`en_estat_reserva`,`res`.`imp_tot_reserva` having (`Import pendent` > 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_resum_clients`
--

/*!50001 DROP VIEW IF EXISTS `v_resum_clients`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_resum_clients` AS select concat(`cli`.`nom_client`,' ',`cli`.`cognoms_client`) AS `Client`,count(`res`.`id_reserva`) AS `Nombre reserves`,coalesce(sum(`pag`.`total_pagat`),0) AS `Total pagat`,(coalesce(sum(`res`.`imp_tot_reserva`),0) - coalesce(sum(`pag`.`total_pagat`),0)) AS `Import pendent acumulat` from ((`CLIENTS` `cli` left join `RESERVES` `res` on((`cli`.`id_client` = `res`.`id_client`))) left join (select `PAGAMENTS`.`id_reserva` AS `id_reserva`,sum(`PAGAMENTS`.`import_paga`) AS `total_pagat` from `PAGAMENTS` group by `PAGAMENTS`.`id_reserva`) `pag` on((`res`.`id_reserva` = `pag`.`id_reserva`))) group by `cli`.`id_client`,`cli`.`nom_client`,`cli`.`cognoms_client` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_resum_reserves`
--

/*!50001 DROP VIEW IF EXISTS `v_resum_reserves`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_resum_reserves` AS select `res`.`id_reserva` AS `id_reserva`,concat(`cli`.`nom_client`,' ',`cli`.`cognoms_client`) AS `Client`,`hab`.`num_habitacio` AS `Habitació`,`tip_hab`.`nom_tipus_hab` AS `Tipus`,`res`.`data_entra_reserva` AS `Data entr.`,`res`.`data_surt_reserva` AS `Data surt.`,`res`.`quantitat_nits_reserva` AS `# nits`,`res`.`en_estat_reserva` AS `Estat reserva`,`res`.`imp_tot_reserva` AS `Import total` from (((`RESERVES` `res` join `CLIENTS` `cli` on((`res`.`id_client` = `cli`.`id_client`))) join `HABITACIONS` `hab` on((`res`.`id_habitacio` = `hab`.`id_habitacio`))) join `TIPUS_HABITACIONS` `tip_hab` on((`hab`.`id_tipus_hab` = `tip_hab`.`id_tipus_hab`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-03 12:02:11
