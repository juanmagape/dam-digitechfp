-- Data del dump -> 03/06/2026 a les 12:02:08

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_import_pendent`(p_id_reserva DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
DECLARE import_total DECIMAL(10,2);
DECLARE import_pagat DECIMAL(10,2);
SELECT imp_tot_reserva INTO import_total
FROM RESERVES 
WHERE id_reserva = p_id_reserva;
SELECT SUM(import_paga) INTO import_pagat 
FROM PAGAMENTS 
WHERE id_reserva = p_id_reserva; 
IF import_pagat IS NULL THEN
        SET import_pagat = 0.00;
    END IF;
    RETURN import_total - import_pagat;
END ;;
DELIMITER ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_total_pagat`(p_id_reserva INT) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE v_import_total DECIMAL(10,2); 
    SELECT SUM(import_paga) INTO v_import_total 
    FROM PAGAMENTS
    WHERE id_reserva = p_id_reserva;
    RETURN v_import_total;
END ;;
DELIMITER ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_afegir_pagament`(
    IN p_id_reserva INT, 
    IN p_import DECIMAL(10,2), 
    IN p_metode VARCHAR(50), 
    IN p_descripcio VARCHAR(255)
)
BEGIN
    IF p_import <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: L''import ha de ser superior a 0.';
    END IF;
    INSERT INTO PAGAMENTS (id_reserva, import_paga, metode_paga, concepte_paga) 
    VALUES (p_id_reserva, p_import, p_metode, p_descripcio);
    UPDATE RESERVES 
    SET en_estat_reserva = 'confirmada' 
    WHERE id_reserva = p_id_reserva 
      AND en_estat_reserva = 'pendent'
      AND imp_tot_reserva <= (
          SELECT SUM(import_paga) FROM PAGAMENTS WHERE id_reserva = p_id_reserva
      );
END ;;
DELIMITER ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_checkout_reserva`(IN p_id_reserva INT)
BEGIN
    IF (SELECT imp_tot_reserva FROM RESERVES WHERE id_reserva = p_id_reserva) > 
       IFNULL((SELECT SUM(import_paga) FROM PAGAMENTS WHERE id_reserva = p_id_reserva), 0) THEN
       
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Hi ha pagaments pendents. No es pot fer el checkout.';
    END IF;
    UPDATE RESERVES SET en_estat_reserva = 'checkout' WHERE id_reserva = p_id_reserva;
END ;;
DELIMITER ;
