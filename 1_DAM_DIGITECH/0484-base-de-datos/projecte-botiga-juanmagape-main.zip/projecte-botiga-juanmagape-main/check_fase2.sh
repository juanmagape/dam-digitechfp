#!/bin/bash

FILE="sql/hotel_reserves/01-exploracio.md"

ERRORS=0

echo "Comprovant Fase 2..."

if [ ! -f "$FILE" ]; then
    echo "ERROR: No existeix el fitxer"
    exit 1
fi

TABLES=("CLIENTS" "RESERVES" "HABITACIONS" "PAGAMENTS")

for TABLE in "${TABLES[@]}"; do
    grep -q "## Taula: $TABLE" "$FILE" || ERRORS=1
done

grep -q "### Comanda" "$FILE" || ERRORS=1
grep -q "### Sortida" "$FILE" || ERRORS=1
grep -q "### Interpretació" "$FILE" || ERRORS=1

grep -q '```sql' "$FILE" || ERRORS=1

grep -q "DESC CLIENTS;" "$FILE" || ERRORS=1

if [ $ERRORS -eq 0 ]; then
    echo "OK: Format correcte"
else
    echo "Hi ha errors. Revisa l'enunciat."
fi
